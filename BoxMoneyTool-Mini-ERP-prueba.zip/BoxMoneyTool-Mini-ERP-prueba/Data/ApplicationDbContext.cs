﻿using Microsoft.EntityFrameworkCore;
using BoxMoneyTool.Models;
namespace BoxMoneyTool.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options) { }

        // DbSets para todas tus entidades
        public DbSet<Categoria> Categorias { get; set; }
        public DbSet<Cliente> Clientes { get; set; }
        public DbSet<DetalleFactura> DetallesFactura { get; set; }
        public DbSet<Factura> Facturas { get; set; }
        public DbSet<Permiso> Permisos { get; set; }
        public DbSet<Producto> Productos { get; set; }
        public DbSet<Proveedor> Proveedores { get; set; }
        public DbSet<Rol> Roles { get; set; }
        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Carrito> Carritos { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Relaciones entre entidades
            // 🔹 Relación muchos a muchos: Producto ↔ Proveedor
            modelBuilder.Entity<Producto>()
                .HasMany(p => p.Proveedores)
                .WithMany(pr => pr.Productos)
                .UsingEntity(j => j.ToTable("ProductoProveedor"));

            // 🔹 Relación muchos a muchos: Rol ↔ Permiso
            modelBuilder.Entity<Rol>()
                .HasMany(r => r.Permisos)
                .WithMany(p => p.Roles)
                .UsingEntity(j => j.ToTable("RolPermiso"));

            // 🔹 Relación uno a muchos: Usuario ↔ Rol
            modelBuilder.Entity<Usuario>()
                .HasOne(u => u.Rol)
                .WithMany(r => r.Usuarios)
                .HasForeignKey(u => u.IDRol)
                .OnDelete(DeleteBehavior.Restrict);


            // Reglas para evitar actualización de campos FechaCreacion
            // Categoria
            modelBuilder.Entity<Categoria>()
                .Property(c => c.FechaCreacion)
                .ValueGeneratedOnAdd()
                .Metadata.SetAfterSaveBehavior(Microsoft.EntityFrameworkCore.Metadata.PropertySaveBehavior.Ignore);

            // Cliente
            modelBuilder.Entity<Cliente>()
                .Property(c => c.FechaCreacion)
                .ValueGeneratedOnAdd()
                .Metadata.SetAfterSaveBehavior(Microsoft.EntityFrameworkCore.Metadata.PropertySaveBehavior.Ignore);

            // Factura
            modelBuilder.Entity<Factura>()
                .Property(c => c.FechaEmision)
                .ValueGeneratedOnAdd()
                .Metadata.SetAfterSaveBehavior(Microsoft.EntityFrameworkCore.Metadata.PropertySaveBehavior.Ignore);

            // Permiso
            modelBuilder.Entity<Permiso>()
                .Property(c => c.FechaCreacion)
                .ValueGeneratedOnAdd()
                .Metadata.SetAfterSaveBehavior(Microsoft.EntityFrameworkCore.Metadata.PropertySaveBehavior.Ignore);

            // Producto
            modelBuilder.Entity<Producto>()
                .Property(c => c.FechaCreacion)
                .ValueGeneratedOnAdd()
                .Metadata.SetAfterSaveBehavior(Microsoft.EntityFrameworkCore.Metadata.PropertySaveBehavior.Ignore);

            // Proveedor
            modelBuilder.Entity<Proveedor>()
                .Property(c => c.FechaCreacion)
                .ValueGeneratedOnAdd()
                .Metadata.SetAfterSaveBehavior(Microsoft.EntityFrameworkCore.Metadata.PropertySaveBehavior.Ignore);

            // Rol
            modelBuilder.Entity<Rol>()
                .Property(c => c.FechaCreacion)
                .ValueGeneratedOnAdd()
                .Metadata.SetAfterSaveBehavior(Microsoft.EntityFrameworkCore.Metadata.PropertySaveBehavior.Ignore);

            // Usuario
            modelBuilder.Entity<Usuario>()
                .Property(c => c.FechaCreacion)
                .ValueGeneratedOnAdd()
                .Metadata.SetAfterSaveBehavior(Microsoft.EntityFrameworkCore.Metadata.PropertySaveBehavior.Ignore);


            // Regla para declarar la llave foránea mediante Fluent API
            // Categoria en Producto
            /*modelBuilder.Entity<Producto>()
                .HasOne(p => p.Categoria)
                .WithMany(c => c.Productos)
                .HasForeignKey(p => p.IDCategoria)
                .OnDelete(DeleteBehavior.Cascade); // o Restrict, según tu caso*/


            // Datos iniciales (roles predeterminados)
            modelBuilder.Entity<Rol>().HasData(
                new Rol { IDRol = 1, Nombre = "Admin" },
                new Rol { IDRol = 2, Nombre = "User" }
            );

        }
    }
}
