﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace BoxMoneyTool.Migrations
{
    /// <inheritdoc />
    public partial class CostoPromedio : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "Roles",
                keyColumn: "IDRol",
                keyValue: 1);

            migrationBuilder.DeleteData(
                table: "Roles",
                keyColumn: "IDRol",
                keyValue: 2);

            migrationBuilder.InsertData(
                table: "Roles",
                columns: new[] { "IDRol", "Descripcion", "FechaCreacion", "FechaModificacion", "IDPermiso", "Nombre" },
                values: new object[,]
                {
                    { 1, null, new DateTime(2026, 1, 17, 19, 29, 37, 950, DateTimeKind.Local).AddTicks(7700), null, 0, "Admin" },
                    { 2, null, new DateTime(2026, 1, 17, 19, 29, 37, 950, DateTimeKind.Local).AddTicks(7713), null, 0, "User" }
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Roles",
                keyColumn: "IDRol",
                keyValue: 1,
                column: "FechaCreacion",
                value: new DateTime(2026, 1, 17, 1, 19, 21, 733, DateTimeKind.Local).AddTicks(9166));

            migrationBuilder.UpdateData(
                table: "Roles",
                keyColumn: "IDRol",
                keyValue: 2,
                column: "FechaCreacion",
                value: new DateTime(2026, 1, 17, 1, 19, 21, 733, DateTimeKind.Local).AddTicks(9180));
        }
    }
}
