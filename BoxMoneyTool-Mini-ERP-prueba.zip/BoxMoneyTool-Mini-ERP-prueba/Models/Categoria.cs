﻿// Librerías
using Azure.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;


// Espacio de columnas de la tabla 'Categoria'
public class Categoria
{
    [Key]
    public int IDCategoria { get; set; }

    [Required(ErrorMessage = "El nombre es obligatorio.")]
    [MaxLength(30)]
    public required string Nombre { get; set; }

    [MaxLength(100)]
    public string? Descripcion { get; set; }

    [DataType(DataType.Date)]
    public DateTime FechaCreacion { get; set; } = DateTime.Now;

    [DataType(DataType.Date)]
    public DateTime? FechaModificacion { get; set; }


    // Relación uno a muchos con 'Producto'
    public virtual ICollection<Producto> Productos { get; set; } = new List<Producto>();
}
