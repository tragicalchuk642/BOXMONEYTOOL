﻿// Librerías
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Espacio de columnas de la tabla 'Carrito'
public class Carrito
{
    [Key]
    public int IDCarrito { get; set; }

    [Required(ErrorMessage = "La cantidad es obligatoria."),
        Range(1, int.MaxValue, ErrorMessage = "La cantidad debe ser al menos 1.")]
    public int Cantidad { get; set; }

    [DataType(DataType.Date)]
    public DateTime FechaCreacion { get; set; } = DateTime.Now; // Útil para limpiar carritos viejos automáticamente


    // Relaciones
    [ForeignKey("Producto")]
    public int IDProducto { get; set; }
    public virtual Producto Producto { get; set; } = null!;

    // Identificador de usuario
    // Esto evita que si dos vendedores usan el sistema, sus carritos se mezclen.
    [MaxLength(450)]
    public string? IDUsuario { get; set; }
}

