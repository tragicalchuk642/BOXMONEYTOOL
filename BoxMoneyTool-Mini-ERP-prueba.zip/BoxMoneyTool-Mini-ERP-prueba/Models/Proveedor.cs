﻿// Librerías
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


// Espacio de columnas de la tabla 'Proveedor'
public class Proveedor
{
    [Key]
    public int IDProveedor { get; set; }

    [MaxLength(15)]
    public string? NIT { get; set; }

    [MaxLength(50)]
    public string? Nombre { get; set; }

    [EmailAddress, MaxLength(75)]
    public string? Correo { get; set; }

    [MaxLength(150)]
    public string? Direccion { get; set; }

    [MaxLength(75)]
    public string? Ciudad { get; set; }

    [MaxLength(15)]
    public string? Telefono { get; set; }

    [DataType(DataType.Date)]
    public DateTime FechaCreacion { get; set; } = DateTime.Now;

    [DataType(DataType.Date)]
    public DateTime? FechaModificacion { get; set; }


    // Relaciones
    // Uno a muchos con 'Producto' para generar una tabla intermedia implícita
    public virtual ICollection<Producto> Productos { get; set; } = new List<Producto>();

    // Uno a muchos con 'Factura'
    public virtual ICollection<Factura> Facturas { get; set; } = new List<Factura>();
}
