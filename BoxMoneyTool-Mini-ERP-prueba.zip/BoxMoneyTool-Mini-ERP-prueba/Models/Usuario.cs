﻿// Librerías
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


// Espacio de columnas de la tabla 'Usuario'
public class Usuario
{
    [Key]
    public int IDUsuario { get; set; }

    [Required(ErrorMessage = "Proporcione el nombre completo del empleado.")]
    [MaxLength(50)]
    public required string NombreCompleto { get; set; }

    [Required(ErrorMessage = "Asígnele un correo empresarial al empleado para acceder al sistema.")]
    [EmailAddress, MaxLength(75)]
    public required string Correo { get; set; }

    [Required(ErrorMessage = "Proporcione una contraseña para que el empleado pueda acceder al sistema.")]
    [MaxLength(45)]
    public required string Contraseña { get; set; }

    [DataType(DataType.Date)]
    public DateTime FechaCreacion { get; set; } = DateTime.Now;

    [DataType(DataType.Date)]
    public DateTime? FechaModificacion { get; set; }


    // Relaciones
    // Uno a muchos con 'Factura'
    public virtual ICollection<Factura> Facturas { get; set; } = new List<Factura>();

    // Muchos a uno con 'Rol'
    [Required(ErrorMessage = "Debe asignarle un rol al usuario.")]
    public int IDRol { get; set; }

    public virtual Rol? Rol { get; set; } = null!;
}