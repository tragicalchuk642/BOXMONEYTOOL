﻿// Librerías
using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


// Espacio de columnas de la tabla 'Producto'
public class Producto
{
    [Key]
    public int IDProducto { get; set; }

    [Required(ErrorMessage = "El nombre es obligatorio.")]
    [MaxLength(30)]
    public required string Nombre { get; set; }

    [Required(ErrorMessage = "La descripción es obligatoria.")]
    [MaxLength(200)]
    public required string Descripcion { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal Precio { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal CostoPromedio { get; set; }

    public int? StockMinimo { get; set; }

    public int? StockMaximo { get; set; }

    public int StockActual { get; set; }

    [MaxLength(255)]
    public string? ImagenURL { get; set; } 

    [DataType(DataType.Date)]
    public DateTime FechaCreacion { get; set; } = DateTime.Now;

    [DataType(DataType.Date)]
    public DateTime? FechaModificacion { get; set; }


    // Relaciones
    // Muchos a uno con 'Categoria'
    [Required(ErrorMessage = "Debe seleccionar una categoría para el producto.")]
    [ForeignKey("Categoria")]
    public int IDCategoria { get; set; }
    public virtual Categoria Categoria { get; set; } = null!;

    // Uno a muchos con 'DetalleVenta'
    public virtual ICollection<DetalleFactura> DetallesFactura { get; set; } = new List<DetalleFactura>();

    // Uno a muchos con 'Proveedor' para generar una tabla intermedia implícita
    public virtual ICollection<Proveedor> Proveedores { get; set; } = new List<Proveedor>();
}
