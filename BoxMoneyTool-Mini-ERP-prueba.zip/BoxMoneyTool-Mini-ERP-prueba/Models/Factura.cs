﻿// Librerías
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using BoxMoneyTool.Models;

// Espacio de columnas de la tabla 'Factura'
public class Factura
{
    [Key]
    public int IDFactura { get; set; }

    [Required(ErrorMessage = "Indique si la factura es de compra o venta.")]
    [MaxLength(20)]
    public required string TipoFactura { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal PrecioTotal { get; set; }

    [Required(ErrorMessage = "El estado de la factura es obligatorio.")]
    [MaxLength(20)]
    public required string Estado { get; set; } = "Emitida"; // Valores posibles: "Emitida" o "Cancelada"

    [DataType(DataType.Date)]
    public DateTime FechaEmision { get; set; } = DateTime.Now;

    public DateTime? FechaAnulacion { get; set; }


    // Relaciones
    // Muchos a uno con 'Usuario'
    [Required(ErrorMessage = "El usuario es obligatorio para crear la factura.")]
    [ForeignKey("Usuario")]
    public int IDUsuario { get; set; }
    public virtual Usuario Usuario { get; set; } = null!;

    // Muchos a uno con 'Proveedor'
    [ForeignKey("Proveedor")]
    public int? IDProveedor { get; set; }
    public virtual Proveedor Proveedor { get; set; } = null!;

    // Muchos a uno con 'Cliente'
    [ForeignKey("Cliente")]
    public int? IDCliente { get; set; }
    public virtual Cliente Cliente { get; set; } = null!;

    // Uno a muchos con 'DetalleFactura'
    public virtual ICollection<DetalleFactura> DetallesFactura { get; set; } = new List<DetalleFactura>();
}

