﻿//Librerías
using System;
using System.ComponentModel.DataAnnotations;

namespace BoxMoneyTool.Models.ViewModels
{
    public class InventarioKardexViewModel
    {
        // Información del Movimiento (Desde DetalleFactura/Factura)
        public int IDMovimiento { get; set; } // IDDetalleFactura
        public int IDFactura { get; set; }    // Para poder ir a ver la factura completa

        [Display(Name = "Fecha")]
        public DateTime FechaMovimiento { get; set; }

        [Display(Name = "Movimiento")]
        public string TipoMovimiento { get; set; } // "Compra" o "Venta"

        // Información del Producto
        public string NombreProducto { get; set; }
        public string Categoria { get; set; }

        // Cifras
        public int Cantidad { get; set; }

        // A. Lo que pediste: Costo Promedio (Estado ACTUAL del producto)
        [Display(Name = "Costo Prom. Actual")]
        public decimal CostoPromedioActual { get; set; }

        // B. Lo que realmente ocurrió: Precio de la Factura
        [Display(Name = "Precio Transacción")]
        public decimal PrecioUnitarioFactura { get; set; }

        // Cálculos Totales
        [Display(Name = "Total Costo Actual")]
        public decimal TotalCostoPromedio => Cantidad * CostoPromedioActual;

        [Display(Name = "Total Transacción")]
        public decimal TotalTransaccion => Cantidad * PrecioUnitarioFactura;

        public int Orden { get; set; } // Para ordenar movimientos en caso de ser necesario
    }
}