﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class UsuarioViewModel {
    public int IDUsuario { get; set; }

    [Required(ErrorMessage = "Proporcione el nombre completo del empleado.")]
    [MaxLength(50)]
    public string NombreCompleto { get; set; }

    [Required(ErrorMessage = "Asígnele un correo empresarial al empleado para acceder al sistema.")]
    [EmailAddress, MaxLength(75)]
    public string Correo { get; set; }

    [Required(ErrorMessage = "Proporcione una contraseña para que el empleado pueda acceder al sistema.")]
    [MaxLength(45)]
    public string Contraseña { get; set; }

    [Required(ErrorMessage = "Debe asignarle un rol al usuario."),
        Display(Name = "Rol")]
    public int IDRol { get; set; }

    public IEnumerable<SelectListItem> RolesDisponibles { get; set; } = Enumerable.Empty<SelectListItem>();
}
