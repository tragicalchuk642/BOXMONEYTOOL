﻿// Librerías
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BoxMoneyTool.ViewModel
{
    public class ProductoViewModel
    {
        public int IDProducto { get; set; } //Puede ser necesario para la edición

        [Required(ErrorMessage = "El nombre es obligatorio."),
            MaxLength(30)]
        public string Nombre { get; set; }

        [Required(ErrorMessage = "La descripción es obligatoria."),
            MaxLength(200)]
        public string Descripcion { get; set; }

        public decimal Precio { get; set; }
        public decimal CostoPromedio { get; set; }

        public int? StockMinimo { get; set; }
        public int? StockMaximo { get; set; }
        public int StockActual { get; set; }

        [MaxLength(255)]
        public string? ImagenURL { get; set; }

        public IFormFile? ImagenActual { get; set; }

        [Required(ErrorMessage = "Debe seleccionar una categoría para el producto."),
            Display(Name = "Categoría")]
        public int IDCategoria { get; set; }

        public IEnumerable<SelectListItem> CategoriasDisponibles { get; set; } = Enumerable.Empty<SelectListItem>();

 
    }
}
