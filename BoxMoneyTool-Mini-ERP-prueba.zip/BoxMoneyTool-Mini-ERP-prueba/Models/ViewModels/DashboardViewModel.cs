﻿// Librerías.

// Propiedades a usar en el controlador y vistas
public class DashboardViewModel
{
    // --- 1. TARJETAS DE RESUMEN (KPIs) ---
    public decimal VentasTotalesMes { get; set; }
    public int CantidadFacturasMes { get; set; }
    public decimal TicketPromedio { get; set; } // Cuánto gasta un cliente en promedio

    // --- 2. DATOS PARA EL GRÁFICO (Ventas por Día) ---
    // Chart.js necesita dos listas: Etiquetas (Días) y Valores (Dinero)
    public string[] GraficoEtiquetas { get; set; } = null!; // Ej: ["01/12", "02/12", ...]
    public decimal[] GraficoValores { get; set; } = null!; // Ej: [150000, 200000, ...]

    // --- 3. LISTAS DE DETALLE (Top Productos, top clientes y Últimas Ventas) ---
    public List<ProductoTopVenta> TopProductos { get; set; } = new List<ProductoTopVenta>();
    public List<Factura> UltimasVentas { get; set; } = new List<Factura>();
    public List<ClienteTopVenta> TopClientes { get; set; } = new List<ClienteTopVenta>();

    // KPI: Cuánto dinero tienes invertido en mercancía
    public decimal ValorTotalInventario { get; set; }

    // KPI: Cuántos productos distintos tienes
    public int TotalReferencias { get; set; }

    // GRÁFICO TORTA: Distribución por Categoría
    public string[] CategoriasEtiquetas { get; set; } = null!;
    public int[] CategoriasValores { get; set; } = null!;
    public decimal[] CategoriasDinero { get; set; } = null!;

    public List<ProductoInventario> InventarioCompleto { get; set; } = new List<ProductoInventario>();

    // ALERTA: Lista de productos que necesitan reposición
    public List<ProductoAlertaStock> ProductosBajoStock { get; set; } = new List<ProductoAlertaStock>();

    // --- NUEVO: FLUJO DE CAJA ---
    public decimal TotalEgresos { get; set; }   // Compras a Proveedores
    public decimal BalanceNeto { get; set; }    // Ingresos - Egresos
    public decimal MargenGanancia { get; set; } // Porcentaje de rentabilidad

    // Para el gráfico comparativo (Barras: Ingreso vs Egreso)
    public decimal[] FlujoValores { get; set; } = null!; // [TotalVentas, TotalCompras]
}

// Clase auxiliar pequeña para la lista de Top Productos
public class ProductoTopVenta
{
    public string NombreProducto { get; set; } = null!;
    public int CantidadVendida { get; set; }
    public decimal TotalGenerado { get; set; }
}

// Clase auxiliar pequeña para la lista de Top Clientes
public class ClienteTopVenta
{
    public string NombreCliente { get; set; } = null!;
    public int CantidadCompras { get; set; }
    public decimal TotalGastado { get; set; }
}

// Clase auxiliar para la tabla de alertas
public class ProductoAlertaStock
{
    public string Nombre { get; set; } = null!;
    public int StockActual { get; set; }
    public int? StockMinimo { get; set; }
    public string Categoria { get; set; } = null!;
    public decimal CostoPromedio { get; set; }
}

public class ProductoInventario
{
    public string Nombre { get; set; } = null!;
    public string Categoria { get; set; } = null!;
    public int Stock { get; set; }
    public decimal Costo { get; set; }
    public decimal ValorTotal { get; set; } // Stock * Costo
}