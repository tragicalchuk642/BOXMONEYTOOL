﻿// Librerías
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class FacturaViewModel
{
    public int IDFactura { get; set; }

    [Required(ErrorMessage = "Indique si la factura es de compra o venta."),
        MaxLength(20),
        Display(Name = "Tipo de factura")]
    public string TipoFactura { get; set; } = "Venta"; // "Venta" o "Compra"

    [Required(ErrorMessage = "El estado de la factura es obligatorio."),
        MaxLength(20),
        Display(Name = "Estado")]
    public string Estado { get; set; } = "Emitida";

    [Display(Name = "Fecha de emisión")]
    public DateTime FechaEmision { get; set; } = DateTime.Today;

    [Required(ErrorMessage = "El usuario es obligatorio para crear la factura."),
        Display(Name = "Usuario")]
    public int IDUsuario { get; set; }

    [Display(Name = "Proveedor")]
    public int? IDProveedor { get; set; }

    [Display(Name = "Cliente")]
    public int? IDCliente { get; set; }


    // Listas desplegables
    public IEnumerable<SelectListItem> UsuariosDisponibles { get; set; } = Enumerable.Empty<SelectListItem>();
    public IEnumerable<SelectListItem> ProveedoresDisponibles { get; set; } = Enumerable.Empty<SelectListItem>();
    public IEnumerable<SelectListItem> ClientesDisponibles { get; set; } = Enumerable.Empty<SelectListItem>();
    public IEnumerable<SelectListItem> ProductosDisponibles { get; set; } = Enumerable.Empty<SelectListItem>();


    // Lista para los tipos (Compra/Venta)
    public IEnumerable<SelectListItem> TiposFacturaDisponibles { get; set; } = new List<SelectListItem>
    {
        new SelectListItem { Value = "Venta", Text = "Venta" },
        new SelectListItem { Value = "Compra", Text = "Compra" }
    };

    public IEnumerable<SelectListItem> EstadosDisponibles { get; set; } = new List<SelectListItem>
    {
        new SelectListItem { Value = "Emitida", Text = "Emitida" },
        new SelectListItem { Value = "Cancelada", Text = "Cancelada" }
    };

    // Lista de detalles. Llenada mediante JavaScript y recibida por el controlador
    public virtual ICollection<DetallesFacturaViewModel> Detalles { get; set; } = new List<DetallesFacturaViewModel>();

}
