﻿// Librerías
using BoxMoneyTool.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class RolsViewModel {
    public int IDRol { get; set; }

    [Required(ErrorMessage = "El nombre es obligatorio.")]
    [MaxLength(30)]
    public string Nombre { get; set; }

    [MaxLength(100)]
    public string? Descripcion { get; set; }


    // Relaciones
    public int IDPermiso { get; set; }
    public IEnumerable<SelectListItem>PermisosDisponibles { get; set; } = Enumerable.Empty<SelectListItem>();

}
