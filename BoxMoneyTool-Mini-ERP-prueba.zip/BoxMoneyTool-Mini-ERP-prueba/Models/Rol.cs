﻿// Librerías
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using BoxMoneyTool.Models;

// Espacio de columnas de la tabla 'Rol'
public class Rol
{
    [Key]
    public int IDRol { get; set; }

    [Required(ErrorMessage = "El nombre es obligatorio.")]
    [MaxLength(30)]
    public required string Nombre { get; set; }

    [MaxLength(100)]
    public string? Descripcion { get; set; }

    [DataType(DataType.Date)]
    public DateTime FechaCreacion { get; set; } = DateTime.Now;

    [DataType(DataType.Date)]
    public DateTime? FechaModificacion { get; set; }


    // Relaciones
    // Uno a muchos con 'Usuario'
    public virtual ICollection<Usuario> Usuarios { get; set; } = new List<Usuario>();

    // Uno a muchos con 'Permiso'
    public int IDPermiso { get; set; }
    public virtual ICollection<Permiso> Permisos { get; set; } = new List<Permiso>();
}