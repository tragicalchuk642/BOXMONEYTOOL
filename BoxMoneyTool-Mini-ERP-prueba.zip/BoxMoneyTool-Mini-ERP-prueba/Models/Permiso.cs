﻿// Librerías
using System;
using System.ComponentModel.DataAnnotations;


// Espacio de columnas de la tabla 'Permiso'
public class Permiso
{
    [Key]
    public int IDPermiso { get; set; }

    [Required(ErrorMessage = "El nombre es obligatorio.")]
    [MaxLength(30)]
    public required string Nombre { get; set; }

    [MaxLength(100)]
    public string? Descripcion { get; set; }

    [DataType(DataType.Date)]
    public DateTime FechaCreacion { get; set; } = DateTime.Now;

    [DataType(DataType.Date)]
    public DateTime? FechaModificacion { get; set; }


    // Relaciones
    // Uno a muchos con 'Rol'
    public virtual ICollection<Rol> Roles { get; set; } = new List<Rol>();
}