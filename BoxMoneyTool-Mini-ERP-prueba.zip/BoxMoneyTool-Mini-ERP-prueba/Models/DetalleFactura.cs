﻿// Librerías
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

// Espacio de columnas de la tabla 'DetalleFactura'
public class DetalleFactura
{
    [Key]
    public int IDDetalleFactura { get; set; }

    [Required(ErrorMessage = "La cantidad es obligatoria.")]
    public int Cantidad { get; set; }

    [Required(ErrorMessage = "El precio unitario es obligatorio."),
        Column(TypeName = "decimal(10, 2)")]
    public decimal PrecioUnitario { get; set; }

    [Column(TypeName = "decimal(10, 2)")]
    public decimal CostoPromedioHistorico { get; set; }


    // Relaciones
    // Muchos a uno con 'Factura'
    [ForeignKey("Factura")]
    public int IDFactura { get; set; }
    public virtual Factura Factura { get; set; } = null!;

    // Muchos a uno con 'Producto'
    [ForeignKey("Producto")]
    public int IDProducto { get; set; }
    public virtual Producto Producto { get; set; } = null!;
}

