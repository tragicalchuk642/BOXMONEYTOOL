﻿// Librerías
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


// Espacio de columnas de la tabla 'Cliente'
public class Cliente
{
    [Key]
    public int IDCliente { get; set; }

    [MaxLength(15)]
    public required string Identificacion { get; set; }

    [MaxLength(50)]
    public required string RazonSocial { get; set; }

    [EmailAddress, MaxLength(75)]
    public string? Correo { get; set; }

    [MaxLength(15)]
    public string? Telefono { get; set; }

    [MaxLength(150)]
    public string? Direccion { get; set; }

    [MaxLength(50)]
    public string? Ciudad { get; set; }
        
    [MaxLength(50)]
    public string? TipoNegocio { get; set; }

    [DataType(DataType.Date)]
    public DateTime FechaCreacion { get; set; } = DateTime.Now;

    [DataType(DataType.Date)]
    public DateTime? FechaModificacion { get; set; }


    // Relaciones
    // Uno a muchos con 'Factura'
    public virtual ICollection<Factura> Facturas { get; set; } = new List<Factura>();
}
