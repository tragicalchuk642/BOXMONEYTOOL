﻿using BoxMoneyTool.Data;
using BoxMoneyTool.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
// using BoxMoneyTool.Models.ViewModels;

public class InventariosController : Controller
{
    private readonly ApplicationDbContext _context;

    public InventariosController(ApplicationDbContext context)
    {
        _context = context;
    }

    // GET: Inventarios
    public async Task<IActionResult> Index(string? tipoMovimiento, string? producto, string? categoria)
    {
        // 1. Obtener la data cruda de la BD
        var dataBase = await _context.DetallesFactura
            .Include(d => d.Factura)
            .Include(d => d.Producto)
                .ThenInclude(p => p.Categoria)
            .ToListAsync(); // Traemos a memoria para manipular

        // 2. Crear la lista de Movimientos ORIGINALES (Tal cual ocurrieron)
        var movimientosOriginales = dataBase.Select(d => new InventarioKardexViewModel
        {
            IDMovimiento = d.IDDetalleFactura,
            IDFactura = d.IDFactura,
            FechaMovimiento = d.Factura.FechaEmision,

            // El nombre original: "Venta" o "Compra"
            TipoMovimiento = d.Factura.TipoFactura,

            NombreProducto = d.Producto.Nombre,
            Categoria = d.Producto.Categoria?.Nombre ?? "Sin Cat",

            // Cantidades originales
            Cantidad = d.Cantidad,

            // Costos
            CostoPromedioActual = d.CostoPromedioHistorico,
            PrecioUnitarioFactura = d.PrecioUnitario,

            // Marca interna para ordenar: 0 = Original
            Orden = 0
        });

        // 3. Crear la lista de DEVOLUCIONES (Solo para las Anuladas)
        // "Inventamos" filas nuevas que contrarresten las originales
        var movimientosDevolucion = dataBase
            .Where(d => d.Factura.Estado == "Anulada")
            .Select(d => new InventarioKardexViewModel
            {
                IDMovimiento = d.IDDetalleFactura, // Mismo ID de ref
                IDFactura = d.IDFactura,

                // TRUCO: Si no tienes campo "FechaAnulacion", usamos la fecha de emisión
                // pero le sumamos un poco de tiempo para que aparezca DESPUÉS en la lista.
                FechaMovimiento = d.Factura.FechaAnulacion ?? d.Factura.FechaEmision,

                // Nombre explícito
                TipoMovimiento = "Devolución " + d.Factura.TipoFactura,

                NombreProducto = d.Producto.Nombre,
                Categoria = d.Producto.Categoria?.Nombre ?? "Sin Cat",

                // Cantidad INVERSA (Visualmente)
                // Nota: En contabilidad, una dev. de venta suma stock, una dev. de compra resta.
                // Aquí solo lo mostramos positivo porque es un "movimiento de retorno".
                Cantidad = d.Cantidad,

                CostoPromedioActual = d.CostoPromedioHistorico,
                PrecioUnitarioFactura = d.PrecioUnitario,

                // Marca interna para ordenar: 1 = Devolución
                Orden = 1
            });

        // 4. UNIR las dos listas y ordenar
        var kardexCompleto = movimientosOriginales
            .Concat(movimientosDevolucion)
            .OrderByDescending(x => x.FechaMovimiento) // Lo más reciente primero
            .ThenByDescending(x => x.IDMovimiento) // Si es la misma fecha, primero la devolución
            .ToList();

        // 5. Cargar listas dinámicas para los selects
        ViewBag.Productos = kardexCompleto
            .Select(x => x.NombreProducto)
            .Distinct()
            .ToList();

        ViewBag.Categorias = kardexCompleto
            .Select(x => x.Categoria)
            .Distinct()
            .ToList();

        ViewBag.TiposMovimiento = kardexCompleto
            .Select(x => x.TipoMovimiento)
            .Distinct()
            .ToList();

        // 6. Aplicar filtros (Si el usuario selecciona alguno)
        if (!string.IsNullOrEmpty(tipoMovimiento))
            kardexCompleto = kardexCompleto
                .Where(x => x.TipoMovimiento == tipoMovimiento)
                .ToList();

        if (!string.IsNullOrEmpty(producto))
            kardexCompleto = kardexCompleto
                .Where(x => x.NombreProducto == producto)
                .ToList();

        if (!string.IsNullOrEmpty(categoria))
            kardexCompleto = kardexCompleto
                .Where(x => x.Categoria == categoria)
                .ToList();

        return View(kardexCompleto);
    }
}