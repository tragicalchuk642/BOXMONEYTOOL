﻿using BoxMoneyTool.Data;
using BoxMoneyTool.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace BoxMoneyTool.Controllers
{
    public class CarritoController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CarritoController(ApplicationDbContext context)
        {
            _context = context;
        }

        private string ObtenerUsuarioActual()
        {
            return User.Identity?.Name ?? "Usuario_Invitado";
        }

        [HttpPost]
        public async Task<IActionResult> AgregarAlCarritoAjax(int IDProducto, int cantidad)
        {
            var producto = await _context.Productos.FindAsync(IDProducto);
            if (producto == null) 
                return Json(new { success = false, message = "Producto no encontrado." });

            // Validación de Stock
            if (producto.StockActual < cantidad)
                return Json(new { success = false, message = $"Stock insuficiente. Solo quedan {producto.StockActual}." });

            string usuario = ObtenerUsuarioActual();

            var carrito = await _context.Carritos
                .FirstOrDefaultAsync(c => c.IDProducto == IDProducto && c.IDUsuario == usuario);

            if (carrito == null)
            {
                carrito = new Carrito
                {
                    IDProducto = IDProducto,
                    Cantidad = cantidad,
                    IDUsuario = usuario,
                    FechaCreacion = DateTime.Now
                };
                _context.Carritos.Add(carrito);
            }
            else
            {
                // Validar que la suma no supere el stock
                if (producto.StockActual < (carrito.Cantidad + cantidad))
                    return Json(new { success = false, message = "No puedes agregar más productos de este tipo. Llegaste al tope." });
                carrito.Cantidad += cantidad;
            }

            await _context.SaveChangesAsync();

            // Recalcular totales del usuario
            int totalProductos = await _context.Carritos
                .Where(c => c.IDUsuario == usuario)
                .SumAsync(i => i.Cantidad);

            return Json(new { success = true, totalProductos });
        }

        public async Task<IActionResult> Index()
        {
            string usuario = ObtenerUsuarioActual();

            var carrito = await _context.Carritos
                .Include(c => c.Producto)
                .Where(c => c.IDUsuario == usuario)
                .ToListAsync();

            // Calcular el total de productos y pasar el total a la vista usando ViewBag
            ViewBag.TotalProductos = carrito.Sum(i => i.Cantidad);
            ViewBag.TotalPagar = carrito.Sum(i => i.Cantidad * i.Producto.Precio);

            return View(carrito);
        }

        [HttpPost]
        public async Task<IActionResult> ActualizarCantidad(int idCarrito, int cambio)
        {
            var item = await _context.Carritos
                .Include(c => c.Producto)
                .FirstOrDefaultAsync(c => c.IDCarrito == idCarrito);

            if (item == null) return Json(new { success = false, message = "Ítem no encontrado" });

            // Lógica para restar
            if (cambio < 0)
            {
                if (item.Cantidad > 1) item.Cantidad--;
                else return Json(new { success = false, message = "La cantidad mínima es 1." });
            }
            // Lógica para sumar
            else
            {
                if (item.Cantidad < item.Producto.StockActual) item.Cantidad++;
                else return Json(new { success = false, message = $"¡Tope de stock! Solo hay {item.Producto.StockActual} disponibles." });
            }
            await _context.SaveChangesAsync();

            // Recalcular totales para enviarlos al Front-End
            string usuario = ObtenerUsuarioActual();
            var carrito = await _context.Carritos
                .Include(c => c.Producto)
                .Where(c => c.IDUsuario == usuario)
                .ToListAsync();

            decimal nuevoTotalItem = item.Cantidad * item.Producto.Precio;
            decimal nuevoTotalFactura = carrito.Sum(x => x.Cantidad * x.Producto.Precio);
            int totalItems = carrito.Sum(x => x.Cantidad);

            return Json(new {
                success = true,
                nuevaCantidad = item.Cantidad,
                nuevoTotalItem = nuevoTotalItem.ToString("C0"),
                nuevoTotalFactura = nuevoTotalFactura.ToString("C0"),
                totalItems = totalItems,
            });
        }

        [HttpPost]
        public async Task<IActionResult> EliminarItem(int idCarrito)
        {
            var carritoItem = await _context.Carritos.FindAsync(idCarrito);
            if (carritoItem != null)
            {
                _context.Carritos.Remove(carritoItem);
                _context.SaveChanges();
            }
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Checkout()
        {
            string usuario = ObtenerUsuarioActual();
            var carrito = await _context.Carritos
                .Include(c => c.Producto)
                .Where(c => c.IDUsuario == usuario)
                .ToListAsync();

            if (!carrito.Any()) return RedirectToAction("Index");

            decimal subtotal = carrito.Sum(c => c.Producto.Precio * c.Cantidad);
            decimal envio = 10000;
            decimal total = subtotal + envio; // Aquí se suman los envíos o impuestos (si aplican)

            return View(carrito);
        }

        [HttpGet]
        public async Task<IActionResult> BuscarClientePorIdentificacion(string identificacion)
        {
            var cliente = await _context.Clientes
                .FirstOrDefaultAsync(c => c.Identificacion == identificacion);
            if (cliente == null) return Json(new { success = false });

            return Json(new {
                success = true,
                data = new {
                    razonSocial = cliente.RazonSocial,
                    telefono = cliente.Telefono,
                    correo = cliente.Correo,
                    direccion = cliente.Direccion,
                    ciudad = cliente.Ciudad
                }
            });
        }

        [HttpPost]
        public async Task<IActionResult> ProcesarPedido(
            string identificacion,
            string nombreCliente,
            string telefono,
            string correoCliente,
            string direccion,
            string ciudad,
            string metodoPago,
            string pasarela)
        {
            string usuario = ObtenerUsuarioActual();
            
            var carrito = await _context.Carritos
                .Include(c => c.Producto)
                .Where(c => c.IDUsuario == usuario)
                .ToListAsync();

            if (!carrito.Any())
            {
                TempData["Error"] = "El carrito está vacío.";
                return RedirectToAction("Index");
            }

            using (var transaccion = await _context.Database.BeginTransactionAsync())
            {
                try
                {
                    // 1. Buscar o crear cliente
                    var cliente = await _context.Clientes
                        .FirstOrDefaultAsync(c => c.Identificacion == identificacion);

                    // Si el cliente existe, se extraen los datos a la vista
                    if (cliente == null)
                    {
                        cliente = new Cliente
                        {
                            Identificacion = identificacion,
                            RazonSocial = nombreCliente,
                            Correo = correoCliente,
                            Telefono = telefono,
                            Direccion = direccion,
                            Ciudad = ciudad,
                            FechaCreacion = DateTime.Now
                        };
                        _context.Clientes.Add(cliente);
                    }
                    // Si no existe, se crea un registro nuevo.
                    else
                    {
                        cliente.Identificacion = identificacion;
                        cliente.RazonSocial = nombreCliente;
                        cliente.Correo = correoCliente;
                        cliente.Telefono = telefono;
                        cliente.Direccion = direccion;
                        cliente.Ciudad = ciudad;
                        _context.Clientes.Update(cliente);
                    }
                    await _context.SaveChangesAsync();

                    // 2. Crear la factura
                    string estadoFactura = "Pendiente";
                    if (metodoPago == "Efectivo") estadoFactura = "Pendiente de pago";

                    var factura = new Factura
                    {
                        FechaEmision = DateTime.Now,
                        TipoFactura = "Venta",
                        Estado = estadoFactura,
                        IDUsuario = 1,
                        IDCliente = cliente.IDCliente,
                        PrecioTotal = 0
                    };

                    _context.Facturas.Add(factura);
                    await _context.SaveChangesAsync();

                    decimal precioTotalCalculado = 0;

                    // 3. Mover items (Detalle de la factura) y descontar stock
                    foreach (var item in carrito)
                    {
                        // Re-validar stock (por si otro usuario compró el mismo producto mientras el cliente estaba en el checkout)
                        if (item.Producto.StockActual < item.Cantidad)
                            throw new Exception($"El producto {item.Producto.Nombre} se ha agotado mientras realizabas tu compra. Por favor, ajusta la cantidad.");

                        // Descontar stock
                        item.Producto.StockActual -= item.Cantidad;
                        _context.Productos.Update(item.Producto);

                        var detalle = new DetalleFactura
                        {
                            IDFactura = factura.IDFactura,
                            IDProducto = item.IDProducto,
                            Cantidad = item.Cantidad,
                            PrecioUnitario = item.Producto.Precio,
                            CostoPromedioHistorico = item.Producto.CostoPromedio
                        };
                        _context.DetallesFactura.Add(detalle);
                        precioTotalCalculado += (detalle.Cantidad * detalle.PrecioUnitario);
                    }

                    // 4. Actualizar total factura
                    decimal envioGratis = 150000;
                    decimal envio = 10000;
                    decimal costoEnvio = (precioTotalCalculado >= envioGratis) ? 0 : envio;
                    factura.PrecioTotal = precioTotalCalculado + costoEnvio;
                    _context.Facturas.Update(factura);

                    // 5. Vaciar carrito del usuario
                    _context.Carritos.RemoveRange(carrito);
                    await _context.SaveChangesAsync();

                    await transaccion.CommitAsync();

                    // 6. Redirección inteligente
                    if (metodoPago == "Digital")
                    {
                        if (pasarela == "PayPal") return RedirectToAction("Index", "Checkout", new { id = factura.IDFactura });
                        else if (pasarela == "PSE") return RedirectToAction("Pagar", new { id = factura.IDFactura });
                    }

                    // Redirigir el detalle de la factura creada
                    return RedirectToAction("ConfirmacionPago", new { id = factura.IDFactura });
                }
                catch (Exception ex)
                {
                    await transaccion.RollbackAsync();
                    TempData["Error"] = "Error al procesar: " + ex.Message;
                    return RedirectToAction("Checkout");
                }
            }
        }

        public async Task<IActionResult> Pagar(int id)
        {
            var factura = await _context.Facturas.FindAsync(id);
            if (factura == null) return NotFound();
            return View(factura);
        }

        public async Task<IActionResult> ConfirmarPagoPSE(int idFactura)
        {
            var factura = await _context.Facturas.FindAsync(idFactura);
            if (factura == null) return RedirectToAction("Index", "Home");

            // Cambiar el estado de la factura
            factura.Estado = "Emitida";

            _context.Facturas.Update(factura);
            await _context.SaveChangesAsync();

            // Gracias por su compra 😁
            return RedirectToAction("ConfirmacionPago", "Carrito", new { id = idFactura });
        }

        public async Task<IActionResult> CancelarPedido(int idFactura)
        {
            var factura = await _context.Facturas
                .Include(f => f.Usuario)
                .FirstOrDefaultAsync(f => f.IDFactura == idFactura);

            if (factura == null) return RedirectToAction("Index", "Home");

            // Buscar los productos que se compraron en esa factura
            var detalles = await _context.DetallesFactura
                .Include(d => d.IDFactura == idFactura)
                .ToListAsync();

            // Devolver el stock
            foreach (var detalle in detalles)
            {
                var producto = await _context.Productos.FindAsync(detalle.IDProducto);
                if (producto != null)
                {
                    producto.StockActual += detalle.Cantidad;
                    _context.Productos.Update(producto);
                }
            }

            factura.Estado = "Anulada";
            _context.Facturas.Update(factura);

            await _context.SaveChangesAsync();

            TempData["Mensaje"] = "El pedido fue cancelado y no se realizó ningún cobro.";
            return RedirectToAction("Index", "Home");
        }

        public async Task<IActionResult> ConfirmacionPago(int id)
        {
            var factura = await _context.Facturas
                .Include(f => f.Usuario)
                .FirstOrDefaultAsync(f => f.IDFactura == id);

            if (factura == null) return RedirectToAction("Index", "Home");
            return View(factura);
        }
    }
}
