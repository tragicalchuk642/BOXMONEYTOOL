﻿using BoxMoneyTool.Data;
using BoxMoneyTool.Models;
using Intercom.Core;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BoxMoneyTool.Controllers
{
    public class UsuariosController : Controller
    {
        private readonly ApplicationDbContext _context;

        public UsuariosController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Usuarios
        public IActionResult Index(string? nombre, int? rol, string? correo)
        {
            var usuarios = _context.Usuarios
                .Include(c => c.Rol)
                .AsQueryable();

            if (!string.IsNullOrEmpty(nombre))
                usuarios = usuarios.Where(c =>
                    c.NombreCompleto.Contains(nombre));

            if (rol.HasValue && rol > 0)
                usuarios = usuarios.Where(c => c.IDRol == rol);

            if (!string.IsNullOrEmpty(correo))
                usuarios = usuarios.Where(c =>
                    c.Correo.Contains(correo));

            return View(usuarios.ToList());
        }

        // GET: Usuarios/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var usuario = await _context.Usuarios
                .FirstOrDefaultAsync(m => m.IDUsuario == id);
            if (usuario == null)
            {
                return NotFound();
            }

            return View(usuario);
        }

        // GET: Usuarios/Create
        public IActionResult Create()
        {
            var viewModel = new UsuarioViewModel
            {
                RolesDisponibles = _context.Roles.Select(r => new SelectListItem
                {
                    Text = r.Nombre,
                    Value = r.IDRol.ToString()
                }).ToList()
            };
            return View(viewModel);
        }

        // POST: Usuarios/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(UsuarioViewModel viewModel)
        {
            viewModel.RolesDisponibles = _context.Roles.Select(r => new SelectListItem
            {
                Text = r.Nombre,
                Value = r.IDRol.ToString()
            }).ToList();

            if (ModelState.IsValid)
            {
                var usuarios = new Usuario
                {
                    NombreCompleto = viewModel.NombreCompleto,
                    Correo = viewModel.Correo,
                    Contraseña = viewModel.Contraseña,
                    IDRol = viewModel.IDRol,
                };
                _context.Add(usuarios);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(viewModel);
        }

        // GET: Usuarios/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var usuario = await _context.Usuarios.FindAsync(id);
            if (usuario == null)
            {
                return NotFound();
            }

            var viewModel = new UsuarioViewModel
            {
                IDUsuario = usuario.IDUsuario,
                NombreCompleto = usuario.NombreCompleto,
                Correo = usuario.Correo,
                Contraseña = usuario.Contraseña,
                IDRol = usuario.IDRol,
                RolesDisponibles = _context.Roles.Select(r => new SelectListItem
                {
                    Text = r.Nombre,
                    Value = r.IDRol.ToString()
                }).ToList()
            };
            return View(viewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, UsuarioViewModel viewModel)
        {
            if (id != viewModel.IDUsuario)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var usuarios = await _context.Usuarios.FindAsync(viewModel.IDUsuario);
                    if (usuarios == null)
                    {
                        return NotFound();
                    }

                    usuarios.NombreCompleto = viewModel.NombreCompleto;
                    usuarios.Correo = viewModel.Correo;
                    usuarios.Contraseña = viewModel.Contraseña;

                    // ✅ Esto faltaba
                    usuarios.IDRol = viewModel.IDRol;

                    usuarios.FechaModificacion = DateTime.Now;

                    _context.Update(usuarios);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UsuarioExists(viewModel.IDUsuario))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            // ✅ Para recargar la lista de roles si hay un error en la validación
            viewModel.RolesDisponibles = _context.Roles.Select(r => new SelectListItem
            {
                Text = r.Nombre,
                Value = r.IDRol.ToString()
            }).ToList();

            return View(viewModel);
        }


        // GET: Usuarios/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var usuario = await _context.Usuarios
                .Include(u => u.Rol)
                .FirstOrDefaultAsync(m => m.IDUsuario == id);
            if (usuario == null)
            {
                return NotFound();
            }

            return View(usuario);
        }

        // POST: Usuarios/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var usuario = await _context.Usuarios.FindAsync(id);
            if (usuario != null)
            {
                _context.Usuarios.Remove(usuario);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool UsuarioExists(int id)
        {
            return _context.Usuarios.Any(e => e.IDUsuario == id);
        }
    }
}
