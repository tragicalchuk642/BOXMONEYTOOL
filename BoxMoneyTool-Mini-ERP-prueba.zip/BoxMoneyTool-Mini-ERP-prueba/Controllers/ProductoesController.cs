﻿using BoxMoneyTool.Data;
using BoxMoneyTool.Migrations;
using BoxMoneyTool.ViewModel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BoxMoneyTool.Controllers
{
    public class ProductoesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ProductoesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Productoes
        public IActionResult Index(string buscar, int? categoriaId, decimal? precioMin, decimal? precioMax)
        {
            var productos = _context.Productos
                .Include(p => p.Categoria)
                .AsQueryable();

            if (!string.IsNullOrEmpty(buscar))
                productos = productos.Where(p => p.Nombre.Contains(buscar));

            if (categoriaId.HasValue && categoriaId > 0)
                productos = productos.Where(p => p.IDCategoria == categoriaId);

            ViewBag.Categorias = _context.Categorias.ToList();

            return View(productos.ToList());
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        public IActionResult AgregarAlCarritoAjax(int IDProducto, int cantidad)
        {
            var producto = _context.Productos.Find(IDProducto);
            if (producto == null) return Json(new { success = false, message = "Producto no encontrado." });

            var carritoItem = _context.Carritos
                .FirstOrDefault(ci => ci.IDProducto == IDProducto);

            if (carritoItem == null)
            {
                carritoItem = new Carrito
                {
                    IDProducto = IDProducto,
                    Cantidad = cantidad
                };
                _context.Carritos.Add(carritoItem);
            }
            else carritoItem.Cantidad += cantidad;
            
            _context.SaveChanges();

            int totalProductos = _context.Carritos.Sum(item => item.Cantidad);
            return Json(new { success = true, totalProductos });
        }

        // GET: Productoes/Details/5
        [Authorize(Roles = "Admin")]
        [HttpGet]
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();
            
            var producto = await _context.Productos
                .FirstOrDefaultAsync(m => m.IDProducto == id);
            if (producto == null) return NotFound();
            
            return View(producto);
        }

        // GET: Productoes/Create
        [Authorize(Roles = "Admin")]
        [HttpGet]
        public IActionResult Create()
        {
            var viewModel = new ProductoViewModel
            {
                CategoriasDisponibles = _context.Categorias.Select(c => new SelectListItem
                {
                    Text = c.Nombre,
                    Value = c.IDCategoria.ToString()
                }).ToList()
            };
            return View(viewModel);
        }

        // POST: Productoes/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create(ProductoViewModel viewModel)
        {
            viewModel.CategoriasDisponibles = _context.Categorias.Select(c => new SelectListItem
            {
                Text = c.Nombre,
                Value = c.IDCategoria.ToString()
            }).ToList();

            if (!ModelState.IsValid) return View(viewModel);

            string? nombreArchivo = null;
            if (viewModel.ImagenActual != null && viewModel.ImagenActual.Length > 0)
            {
                var carpeta = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/img/productos");
                if (!Directory.Exists(carpeta)) Directory.CreateDirectory(carpeta);
                nombreArchivo = Guid.NewGuid().ToString() +
                                Path.GetExtension(viewModel.ImagenActual.FileName);
                var rutaCompleta = Path.Combine(carpeta, nombreArchivo);
                using (var stream = new FileStream(rutaCompleta, FileMode.Create)) await viewModel.ImagenActual.CopyToAsync(stream);
            }

            var producto = new Producto
            {
                Nombre = viewModel.Nombre,
                Descripcion = viewModel.Descripcion,
                IDCategoria = viewModel.IDCategoria,
                StockMinimo = viewModel.StockMinimo,
                StockMaximo = viewModel.StockMaximo,
                ImagenURL = nombreArchivo,
                //ImagenURL = uniqueFileName,

                // Valores iniciales obligatorios
                Precio = 0,
                CostoPromedio = 0,
                StockActual = 0,
            };

            _context.Add(producto);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Productoes/Edit/5
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var producto = await _context.Productos.FindAsync(id);
            if (producto == null) return NotFound();

            var viewModel = new ProductoViewModel
            {
                IDProducto = producto.IDProducto,
                Nombre = producto.Nombre,
                Descripcion = producto.Descripcion,
                IDCategoria = producto.IDCategoria,
                StockMinimo = producto.StockMinimo,
                StockMaximo = producto.StockMaximo,
                ImagenURL = producto.ImagenURL,

                Precio = producto.Precio,
                CostoPromedio = producto.CostoPromedio,
                StockActual = producto.StockActual,

                CategoriasDisponibles = _context.Categorias.Select(c => new SelectListItem
                {
                    Text = c.Nombre,
                    Value = c.IDCategoria.ToString()
                }).ToList()
            };
            return View(viewModel);
        }

        // POST: Productoes/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id, ProductoViewModel viewModel)
        {
            if (id != viewModel.IDProducto) return NotFound();

            if (ModelState.IsValid)
            {
                try
                {
                    var productoBD = await _context.Productos.FindAsync(id);
                    if (productoBD == null) return NotFound();

                    productoBD.Nombre = viewModel.Nombre;
                    productoBD.Descripcion = viewModel.Descripcion;
                    productoBD.IDCategoria = viewModel.IDCategoria;
                    productoBD.StockMinimo = viewModel.StockMinimo;
                    productoBD.StockMaximo = viewModel.StockMaximo;
                    productoBD.FechaModificacion = DateTime.Now;

                    // ===== IMAGEN =====
                    if (viewModel.ImagenActual != null)
                    {
                        string carpeta = Path.Combine(
                            Directory.GetCurrentDirectory(),
                            "wwwroot/img/productos"
                        );
                        Directory.CreateDirectory(carpeta);
                        string nombreArchivo = Guid.NewGuid() + Path.GetExtension(viewModel.ImagenActual.FileName);
                        string rutaCompleta = Path.Combine(carpeta, nombreArchivo);
                        using var stream = new FileStream(rutaCompleta, FileMode.Create);
                        await viewModel.ImagenActual.CopyToAsync(stream);

                        productoBD.ImagenURL = nombreArchivo; // nueva imagen
                    }
                    // si NO sube imagen, se queda la que ya tenía
                    // ==================

                    _context.Update(productoBD);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ProductoExists(viewModel.IDProducto)) return NotFound();
                    else throw;
                }
                return RedirectToAction(nameof(Index));
            }
            return View(viewModel);
        }

        // GET: Productoes/Delete/5
        [HttpGet]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var producto = await _context.Productos
                .Include(p => p.Categoria)
                .FirstOrDefaultAsync(m => m.IDProducto == id);
            if (producto == null) return NotFound();

            return View(producto);
        }

        // POST: Productoes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var producto = await _context.Productos.FindAsync(id);
            if (producto != null)
            {
                _context.Productos.Remove(producto);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool ProductoExists(int id)
        {
            return _context.Productos.Any(e => e.IDProducto == id);
        }

    }
}
