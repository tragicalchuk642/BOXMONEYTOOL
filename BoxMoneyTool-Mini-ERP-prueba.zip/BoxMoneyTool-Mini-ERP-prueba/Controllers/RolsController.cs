﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using BoxMoneyTool.Data;

namespace BoxMoneyTool.Controllers
{
    public class RolsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public RolsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Rols
        public async Task<IActionResult> Index()
        {
            var roles = await _context.Roles.Include(r => r.Permisos).ToListAsync();
            return View(await _context.Roles.ToListAsync());
        }

        // GET: Rols/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rol = await _context.Roles
                .FirstOrDefaultAsync(m => m.IDRol == id);
            if (rol == null)
            {
                return NotFound();
            }

            return View(rol);
        }

        // GET: Rols/Create
        public IActionResult Create()
        {
            var viewModel = new RolsViewModel
            {
                PermisosDisponibles = _context.Permisos.Select(p => new SelectListItem
                {
                    Text = p.Nombre,
                    Value = p.IDPermiso.ToString()
                }).ToList()
            };
            return View(viewModel);
        }

        // POST: Rols/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(RolsViewModel viewModel)
        {
            viewModel.PermisosDisponibles = _context.Permisos.Select(p => new SelectListItem
            {
                Text = p.Nombre,
                Value = p.IDPermiso.ToString()
            }).ToList();

            if (ModelState.IsValid)
            {
                var roles = new Rol
                {
                    Nombre = viewModel.Nombre,
                    Descripcion = viewModel.Descripcion,
                    IDPermiso = viewModel.IDPermiso,
                };
                _context.Add(roles);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(viewModel);
        }

        // GET: Rols/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rol = await _context.Roles.FindAsync(id);
            if (rol == null)
            {
                return NotFound();
            }

            var viewModel = new RolsViewModel
            {
                IDRol = rol.IDRol,
                Nombre = rol.Nombre,
                Descripcion = rol.Descripcion,
                IDPermiso = rol.IDPermiso,
                PermisosDisponibles = _context.Permisos.Select(P => new SelectListItem

                {
                    Text = P.Nombre,
                    Value = P.IDPermiso.ToString()
                }).ToList()

            };
            return View(viewModel);
        }

        // POST: Rols/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, RolsViewModel viewModel) 
        {
            if (id != viewModel.IDRol)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    var roles = await _context.Roles.FindAsync(viewModel.IDRol);
                    if (roles == null)
                    {
                        return NotFound();
                    }
                    roles.Nombre = viewModel.Nombre;
                    roles.Descripcion = viewModel.Descripcion;
                    roles.IDPermiso = viewModel.IDPermiso;  

                    roles.FechaModificacion = DateTime.Now;
                    _context.Update(roles);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!RolExists(viewModel.IDRol))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            viewModel.PermisosDisponibles = _context.Permisos.Select(p => new SelectListItem
            {
                Text = p.Nombre, 
                Value = p.IDPermiso.ToString()
            }).ToList();

            return View(viewModel);
        }

        // GET: Rols/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var rol = await _context.Roles
                .Include(r => r.Permisos)
                .FirstOrDefaultAsync(m => m.IDRol == id);
            if (rol == null)
            {
                return NotFound();
            }

            return View(rol);
        }

        // POST: Rols/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var rol = await _context.Roles.FindAsync(id);
            if (rol != null)
            {

                _context.Roles.Remove(rol);
                await _context.SaveChangesAsync();
            }

            return RedirectToAction(nameof(Index));
        }

        private bool RolExists(int id)
        {
            return _context.Roles.Any(e => e.IDRol == id);
        }
    }
}
