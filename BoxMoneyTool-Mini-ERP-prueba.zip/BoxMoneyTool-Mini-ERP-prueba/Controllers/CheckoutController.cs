﻿using BoxMoneyTool.Data;
using BoxMoneyTool.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Text.Json.Nodes;

namespace BoxMoneyTool.Controllers
{
    public class CheckoutController : Controller
    {
        private readonly ApplicationDbContext _context;
        private string PaypalClientId { get; set; } = "";
        private string PaypalSecret { get; set; } = "";
        private string PaypalUrl { get; set; } = "";

        public CheckoutController(IConfiguration configuration, ApplicationDbContext context)
        {
            _context = context;
            PaypalClientId = configuration["PaypalSettings:ClientId"]!;
            PaypalSecret = configuration["PaypalSettings:Secret"]!;
            PaypalUrl = configuration["PaypalSettings:Url"]!;
        }

        public async Task<IActionResult> Index(int id)
        {
            var factura = await _context.Facturas.FindAsync(id);
            if (factura == null) return RedirectToAction("Index", "Home");

            ViewBag.PaypalClientId = PaypalClientId;
            return View(factura);
        }

        [HttpPost]
        public async Task<JsonResult> CreateOrder([FromBody] PaypalRequest data)
        {
            if (data == null || string.IsNullOrEmpty(data.idFactura) || !int.TryParse(data.idFactura, out int idFactura))
                return new JsonResult(new { error = "El ID de la factura no llegó al servidor." });

            // Buscar el precio real en la tabla de facturas
            var factura = await _context.Facturas.FindAsync(idFactura);
            if (factura == null) return new JsonResult(new { error = "Factura no encontrada en la tabla." });
            string totalAmount = factura.PrecioTotal.ToString("0.00", System.Globalization.CultureInfo.InvariantCulture);

            JsonObject createOrderRequest = new JsonObject();
            createOrderRequest.Add("intent", "CAPTURE");

            JsonObject amount = new JsonObject();
            amount.Add("currency_code", "USD");
            amount.Add("value", totalAmount);

            JsonObject purchaseUnit1 = new JsonObject();
            purchaseUnit1.Add("amount", amount);
            purchaseUnit1.Add("reference_id", idFactura.ToString());

            JsonArray purchaseUnits = new JsonArray();
            purchaseUnits.Add(purchaseUnit1);

            createOrderRequest.Add("purchase_units", purchaseUnits);

            string accessToken = await GetPaypalAccessToken();
            if (string.IsNullOrEmpty(accessToken))
                return new JsonResult(new { error = "Fallo de autenticación con PayPal. Revisa ClientId y Secret." });

            string url = PaypalUrl + "/v2/checkout/orders";

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
                var requestMessage = new HttpRequestMessage(HttpMethod.Post, url);
                requestMessage.Content = new StringContent(createOrderRequest.ToString(), null, "application/json");

                var httpResponse = await client.SendAsync(requestMessage);

                if (httpResponse.IsSuccessStatusCode)
                {
                    var strResponse = await httpResponse.Content.ReadAsStringAsync();
                    var jsonResponse = JsonNode.Parse(strResponse);

                    if (jsonResponse != null)
                    {
                        string paypalOrderId = jsonResponse["id"]?.ToString() ?? "";
                        return new JsonResult(new { Id = paypalOrderId });
                    }
                    else
                    {
                        var errorResponse = await httpResponse.Content.ReadAsStringAsync();
                        return new JsonResult(new { error = "Rechazo de PayPal: " + errorResponse });
                    }
                }
            }
            return new JsonResult(new { error = "Error desconocido al procesar CreateOrder." });
        }

        [HttpPost]
        public async Task<JsonResult> CompleteOrder([FromBody] PaypalRequest data)
        {
            if (data == null || string.IsNullOrEmpty(data.orderID) || string.IsNullOrEmpty(data.idFactura)) 
                return new JsonResult(new { error = "Datos incompletos para completar la orden." });
            
            string accessToken = await GetPaypalAccessToken();
            string url = PaypalUrl + "/v2/checkout/orders/" + data.orderID + "/capture";

            using (var client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("Authorization", "Bearer " + accessToken);
                var requestMessage = new HttpRequestMessage(HttpMethod.Post, url);
                requestMessage.Content = new StringContent("", null, "application/json");

                var httpResponse = await client.SendAsync(requestMessage);

                if (httpResponse.IsSuccessStatusCode)
                {
                    var strResponse = await httpResponse.Content.ReadAsStringAsync();
                    var jsonResponse = JsonNode.Parse(strResponse);

                    if (jsonResponse != null)
                    {
                        string paypalOrderStatus = jsonResponse["status"]?.ToString() ?? "";
                        if (paypalOrderStatus == "COMPLETED")
                        {
                            // Buscar la factura para definir su estado
                            if (int.TryParse(data.idFactura, out int idFactura))
                            {
                                var factura = await _context.Facturas.FindAsync(idFactura);
                                if (factura != null)
                                {
                                    factura.Estado = "Emitida";
                                    _context.Facturas.Update(factura);
                                    await _context.SaveChangesAsync();

                                    return new JsonResult("success");
                                }
                            }
                        }
                    }
                }
            }
            return new JsonResult("error");
        }

        private async Task<string> GetPaypalAccessToken()
        {
            string accessToken = "";
            string Url = PaypalUrl + "/v1/oauth2/token";

            using (var client = new HttpClient())
            {
                string credentials64 = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes(PaypalClientId + ":" + PaypalSecret));
                client.DefaultRequestHeaders.Add("Authorization", "Basic " + credentials64);

                var requestMessage = new HttpRequestMessage(HttpMethod.Post, Url);
                requestMessage.Content = new StringContent("grant_type=client_credentials", null, "application/x-www-form-urlencoded");

                var httpResponse = await client.SendAsync(requestMessage);
                if (httpResponse.IsSuccessStatusCode)
                {
                    var strResponse = await httpResponse.Content.ReadAsStringAsync();
                    var jsonResponse = JsonNode.Parse(strResponse);

                    if (jsonResponse != null) accessToken = jsonResponse["access_token"]!.ToString() ?? "";
                }
            }
            return accessToken;
        }
    }

    public class PaypalRequest
    {
        public string idFactura { get; set; } = "";
        public string orderID { get; set; } = "";
    }
}
