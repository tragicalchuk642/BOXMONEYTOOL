﻿using BoxMoneyTool.Data;
using Intercom.Core;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BoxMoneyTool.Controllers
{
    public class FacturasController : Controller
    {
        private readonly ApplicationDbContext _context;

        public FacturasController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Método para poblar las listas desplegables en el ViewModel
        private async Task PoblarListas(FacturaViewModel viewModel)
        {
            viewModel.UsuariosDisponibles = await _context.Usuarios.Select(u => new SelectListItem
            {
                Text = u.NombreCompleto,
                Value = u.IDUsuario.ToString()
            }).ToListAsync();

            viewModel.ClientesDisponibles = await _context.Clientes.Select(c => new SelectListItem
            {
                Text = c.RazonSocial,
                Value = c.IDCliente.ToString()
            }).ToListAsync();

            viewModel.ProveedoresDisponibles = await _context.Proveedores.Select(p => new SelectListItem
            {
                Text = p.Nombre,
                Value = p.IDProveedor.ToString()
            }).ToListAsync();

            var productos = await _context.Productos.ToListAsync();
            ViewBag.ListaPrecios = productos.ToDictionary(p => p.IDProducto, p => p.Precio);
            viewModel.ProductosDisponibles = await _context.Productos.Select(pr => new SelectListItem
            {
                Text = pr.Nombre,
                Value = pr.IDProducto.ToString()
            }).ToListAsync();
        }

        // GET: Facturas
        public IActionResult Index(string? tipoFactura, string? estado, string? fechaEmision, string? cliente)
        {
            var facturas = _context.Facturas
                .Include(f => f.Usuario)
                .Include(f => f.Cliente)
                .Include(f => f.Proveedor)
                .AsQueryable();

            if (!string.IsNullOrEmpty(tipoFactura))
                facturas = facturas.Where(f => f.TipoFactura == tipoFactura);

            if (!string.IsNullOrEmpty(estado))
                facturas = facturas.Where(f => f.Estado == estado);

            if (!string.IsNullOrEmpty(fechaEmision) && DateTime.TryParse(fechaEmision, out DateTime fecha))
                facturas = facturas.Where(f =>
                    f.FechaEmision.Date == fecha.Date);

            if (!string.IsNullOrEmpty(cliente))
            {
                facturas = facturas.Where(f =>
                    (f.Cliente != null && f.Cliente.RazonSocial.Contains(cliente)) ||
                    (f.Proveedor != null && f.Proveedor.Nombre.Contains(cliente))
                );
            }

            return View(facturas.ToList());
        }

        // GET: Facturas/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();
            
            var factura = await _context.Facturas
                .Include(f => f.Usuario)
                .Include(f => f.Proveedor)
                .Include(f => f.Cliente)
                .Include(f => f.DetallesFactura)
                    .ThenInclude(d => d.Producto)
                .FirstOrDefaultAsync(m => m.IDFactura == id);
            if (factura == null) return NotFound();
            
            return View(factura);
        }

        // GET: Facturas/Create
        public async Task<IActionResult> Create()
        {
            var viewModel = new FacturaViewModel();
            await PoblarListas(viewModel);
            return View(viewModel);
        }

        // POST: Facturas/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(FacturaViewModel viewModel)
        {
            if (!ModelState.IsValid || viewModel.Detalles.Count == 0)
            {
                if (viewModel.Detalles.Count == 0) 
                    ModelState.AddModelError("Detalles", "Debe añadir al menos un producto.");
                await PoblarListas(viewModel);
                return View(viewModel);
            }

            // Iniciar la transacción
            using (var transaccion = await _context.Database.BeginTransactionAsync())
            {
                try
                {
                    // Crear y guardar la cabecera de la factura
                    var facturaMaestra = new Factura
                    {
                        FechaEmision = DateTime.Now, // DateTime.Now temporal. Funcionaba con la conexión al modelo de vista.
                        Estado = viewModel.Estado,
                        TipoFactura = viewModel.TipoFactura,
                        IDUsuario = viewModel.IDUsuario,
                        // Se manejan los IDs según el tipo de factura
                        IDProveedor = (viewModel.TipoFactura == "Compra") ? viewModel.IDProveedor : null,
                        IDCliente = (viewModel.TipoFactura == "Venta") ? viewModel.IDCliente : null,
                        PrecioTotal = 0
                    };

                    _context.Facturas.Add(facturaMaestra);
                    await _context.SaveChangesAsync();

                    // Obtener el ID de la factura recién creada
                    int idNuevaFactura = facturaMaestra.IDFactura;
                    decimal precioTotalCalculado = 0;

                    // Recorrer los detalles del modelo de vista y guardarlos
                    foreach (var detalleVM in viewModel.Detalles)
                    {
                        var producto = await _context.Productos.FindAsync(detalleVM.IDProducto);
                        if (producto == null) throw new Exception("Producto no encontrado.");
                        
                        // --- A. LÓGICA DE STOCK ---
                        if (viewModel.TipoFactura == "Venta")
                        {
                            // 1. VALIDACIÓN DE SEGURIDAD (Solo en Ventas)
                            if (detalleVM.PrecioUnitario < producto.Precio)
                                throw new Exception($"El precio para '{producto.Nombre}' (${detalleVM.PrecioUnitario:N0}) es menor al permitido (${producto.Precio:N0}).");
                            
                            // 2. VALIDACIÓN DE STOCK
                            if (producto.StockActual < detalleVM.Cantidad)
                                throw new Exception($"Stock insuficiente para '{producto.Nombre}'. Disponible: {producto.StockActual}");
                            producto.StockActual -= detalleVM.Cantidad;
                        }
                        else if (viewModel.TipoFactura == "Compra")
                        {
                            // Lógica de costo promedio ponderado (CPP)
                            // Valor total del inventario viejo
                            decimal valorTotalActual = producto.StockActual * producto.CostoPromedio;
                            // Valor total de lo que está entrando nuevo
                            decimal valorTotalCompra = detalleVM.Cantidad * detalleVM.PrecioUnitario;
                            // Nueva cantidad total
                            int nuevoStockActual = producto.StockActual + detalleVM.Cantidad;
                            
                            // Calcular nuevo costo promedio
                            if (nuevoStockActual > 0)
                                producto.CostoPromedio = (valorTotalActual + valorTotalCompra) / nuevoStockActual;
                            producto.Precio = producto.CostoPromedio / 0.9m;
                            producto.StockActual += detalleVM.Cantidad;
                        }
                        // Marcar el producto como modificado explícitamente
                        _context.Productos.Update(producto);

                        _context.DetallesFactura.Add(new DetalleFactura
                        {
                            IDFactura = idNuevaFactura,
                            IDProducto = detalleVM.IDProducto,
                            Cantidad = detalleVM.Cantidad,
                            PrecioUnitario = detalleVM.PrecioUnitario,
                            // Si es Comrpra, se usa el promedio calculado.
                            // Si es venta, se usa el promedio del producto.
                            CostoPromedioHistorico = producto.CostoPromedio
                        });

                        // Calcular el precio total
                        precioTotalCalculado += (detalleVM.PrecioUnitario * detalleVM.Cantidad);
                    }

                    // Actualizar el precio total en la cabecera de la factura
                    facturaMaestra.PrecioTotal = precioTotalCalculado;
                    _context.Facturas.Update(facturaMaestra);

                    await _context.SaveChangesAsync();
                    await transaccion.CommitAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (Exception ex)
                {
                    await transaccion.RollbackAsync();
                    ModelState.AddModelError(string.Empty, "Ocurrió un error al guardar la factura: " + ex.Message);
                    await PoblarListas(viewModel);
                    return View(viewModel);
                }
            }
        }

        // GET: Facturas/Void/5
        public async Task<IActionResult> Void(int? id)
        {
            if (id == null) return NotFound();
            
            var factura = await _context.Facturas
                .Include(f => f.Usuario)
                .Include(f => f.Proveedor)
                .Include(f => f.Cliente)
                .Include(f => f.DetallesFactura)
                    .ThenInclude(d => d.Producto)
                .FirstOrDefaultAsync(m => m.IDFactura == id);

            if (factura == null) return NotFound();
                        
            if (factura.Estado == "Anulada")
            {
                TempData["ErrorMessage"] = "La factura ya está anulada y no se puede anular nuevamente.";
                return RedirectToAction(nameof(Index));
            }

            return View(factura);
        }

        // POST: Facturas/Void/5
        [HttpPost, ActionName("Void")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> VoidConfirmed(int id)
        {
            using (var transaccion = await _context.Database.BeginTransactionAsync())
            {
                try
                {
                    var factura = await _context.Facturas
                        .Include(f => f.DetallesFactura)
                        .FirstOrDefaultAsync(f => f.IDFactura == id);

                    if (factura == null || factura.Estado == "Anulada") return RedirectToAction(nameof(Index));
                    
                    foreach (var detalle in factura.DetallesFactura)
                    {
                        var producto = await _context.Productos.FindAsync(detalle.IDProducto);
                        if (producto != null)
                        {
                            // Anular VENTA (Devolución del cliente)
                            if (factura.TipoFactura == "Venta") producto.StockActual += detalle.Cantidad;
                            
                            // Anular COMPRA (Devolución a proveedor)
                            else if (factura.TipoFactura == "Compra")
                            {
                                // Validar que hay stock para devolver
                                if (producto.StockActual < detalle.Cantidad)
                                    throw new Exception($"No se puede anular la compra. El producto {producto.Nombre} ya fue vendido.");

                                // Recalcular costo promedio
                                // Cuánto vale todo el inventario hoy
                                decimal valorTotalActual = producto.StockActual * producto.CostoPromedio;

                                // Cuánto vale lo que se está devolviendo
                                decimal valorTotalCompra = detalle.Cantidad * detalle.PrecioUnitario;

                                // Restar stock
                                int nuevoStock = producto.StockActual - detalle.Cantidad;

                                if (nuevoStock > 0)
                                {
                                    producto.CostoPromedio = (valorTotalActual - valorTotalCompra) / nuevoStock;
                                    producto.Precio = producto.CostoPromedio / 0.9m;
                                }
                                else
                                {
                                    // Si no queda stock, el costo y el precio son 0
                                    producto.CostoPromedio = 0;
                                    producto.Precio = 0;
                                }
                                producto.StockActual = nuevoStock;
                            }
                            _context.Productos.Update(producto);
                        }
                    }

                    factura.Estado = "Anulada";
                    factura.FechaAnulacion = DateTime.Now;

                    _context.Facturas.Update(factura);
                    await _context.SaveChangesAsync();
                    await transaccion.CommitAsync();
                }
                catch (Exception ex)
                {
                    await transaccion.RollbackAsync();
                    TempData["ErrorMessage"] = "Error al anular: " + ex.Message;
                }
            }
            return RedirectToAction(nameof(Index));
        }

        public async Task<IActionResult> Orders()
        {
            var pedidos = await _context.Facturas
                .Include(f => f.Cliente)
                .Include(f => f.Usuario)
                .Include(f => f.Proveedor)
                //.Where(f => f.Estado == "Pendiente de pago")
                .OrderByDescending(f => f.FechaEmision)
                .ToListAsync();

            return View(pedidos);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateOrderState(int idFactura, string nuevoEstado)
        {
            var factura = await _context.Facturas.FindAsync(idFactura);
            if (factura != null)
            {
                factura.Estado = nuevoEstado;
                _context.Update(factura);
                await _context.SaveChangesAsync();
            }
            
            return RedirectToAction("Orders");
        }

        private bool FacturaExists(int id)
        {
            return _context.Facturas.Any(e => e.IDFactura == id);
        }
    }
}
