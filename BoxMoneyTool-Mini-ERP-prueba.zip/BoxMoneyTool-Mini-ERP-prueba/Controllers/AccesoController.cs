﻿using BoxMoneyTool.Data;
using BoxMoneyTool.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace BoxMoneyTool.Controllers
{
    public class AccesoController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AccesoController(ApplicationDbContext context)
        {
            _context = context;
        }

        // 🔹 GET: Login
        public IActionResult Login()
        {
            return View();
        }

        // 🔹 POST: Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(string correo, string contraseña)
        {
            if (string.IsNullOrEmpty(correo) || string.IsNullOrEmpty(contraseña))
            {
                ModelState.AddModelError("", "Debe ingresar el correo y la contraseña.");
                return View();
            }

            // 🔹 Buscar usuario en base de datos
            var usuario = await _context.Usuarios
                .Include(u => u.Rol)
                .FirstOrDefaultAsync(u => u.Correo == correo && u.Contraseña == contraseña);

            if (usuario == null)
            {
                ModelState.AddModelError("", "Correo o contraseña incorrectos.");
                return View();
            }

            // 🔹 Definir el nombre del rol (por si no existe)
            var nombreRol = usuario.Rol?.Nombre ?? "Usuario";

            // 🔹 Crear los claims
            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, usuario.NombreCompleto),
                new Claim(ClaimTypes.Email, usuario.Correo),
                new Claim(ClaimTypes.Role, usuario.Rol.Nombre),
                new Claim("IDUsuario", usuario.IDUsuario.ToString())
            };

            // 🔹 Crear la identidad del usuario
            var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

            // 🔹 Crear la cookie
            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(claimsIdentity),
                new AuthenticationProperties
                {
                    IsPersistent = true
                });

            return RedirectToAction("Index", "Home");
        }

        // 🔹 GET: Logout
        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Acceso");
        }

        // 🔹 GET: Acceso Denegado
        public IActionResult Denegado()
        {
            return View();
        }

        // 🔹 GET: Registro
        public IActionResult Registro()
        {
            return View();
        }

        // 🔹 POST: Registro
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Registro(Usuario usuario)
        {
            if (!ModelState.IsValid)
                return View(usuario);

            // 🔹 Verificar si el correo ya existe
            bool correoExiste = await _context.Usuarios.AnyAsync(u => u.Correo == usuario.Correo);
            if (correoExiste)
            {
                ModelState.AddModelError("Correo", "Este correo ya está registrado.");
                return View(usuario);
            }

            // 🔹 Asignar valores por defecto
            usuario.FechaCreacion = DateTime.Now;
            usuario.IDRol = 2; // Rol "User" por defecto

            _context.Add(usuario);
            await _context.SaveChangesAsync();

            TempData["MensajeRegistro"] = "Usuario registrado exitosamente. Ahora puede iniciar sesión.";
            return RedirectToAction("Login");
        }
    }
}
