﻿using BoxMoneyTool.Data;
using BoxMoneyTool.Migrations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

using WebApplicationpaypal_1.Models.Paypal_Order;
using WebApplicationpaypal_1.Models.Paypal_Transaction;


public class HomeController : Controller
{
    private readonly ApplicationDbContext _context;

    public HomeController(ApplicationDbContext context)
    {
        _context = context;
    }

    public async Task<IActionResult> Index()
    {
        // ---------------------------------------------------------
        // 1. EL PORTERO DE SEGURIDAD ???
        // ---------------------------------------------------------

        // Opción A: Si usas Identity o Claims (Lo estándar)
        // Verifica si el usuario NO es Admin
        if (!User.IsInRole("Admin") && !User.IsInRole("Administrador"))
        {
            // Si no es Admin, le mostramos la vista aburrida y TERMINAMOS aquí.
            // No calculamos nada de finanzas.
            return View("IndexGeneral");
        }

        // Opción B: Si usas Variables de Sesión manuales (ej: HttpContext.Session)
        /*
        var rolUsuario = HttpContext.Session.GetString("RolUsuario");
        if (rolUsuario != "Admin")
        {
            return View("IndexGeneral");
        }
        */

        // ---------------------------------------------------------
        // 2. SI PASA EL PORTERO (Es Admin), EJECUTAMOS EL DASHBOARD
        // ---------------------------------------------------------

        // ... (Aquí va TODO el código del Dashboard que hicimos antes:
        //      Definir fechas, calcular ventas, inventario, flujo de caja, etc.) ...

        DateTime fechaHoy = DateTime.Today;

        // --- D. OPERACIÓN FINANCIERA ---

        // 1. Definir el rango de fechas (Mes actual)
        DateTime FechaHoy = DateTime.Today;
        DateTime inicioMes = new DateTime(FechaHoy.Year, FechaHoy.Month, 1);

        // 2. Traer las facturas válidas (Venta y No Anuladas)
        // Traemos los datos básicos a memoria para procesarlos o hacemos consultas separadas.
        // Para dashboards simples, consultas separadas son más legibles.

        // --- A. KPIs ---
        var ventasMesQuery = _context.Facturas
            .Where(f => f.FechaEmision >= inicioMes
                        && f.TipoFactura == "Venta"
                        && f.Estado != "Anulada");

        decimal totalVentas = await ventasMesQuery.SumAsync(f => f.PrecioTotal);
        int cantidadVentas = await ventasMesQuery.CountAsync();

        // --- B. GRÁFICO (Agrupar ventas por día) ---
        var datosGrafico = await ventasMesQuery
            .GroupBy(f => f.FechaEmision.Date)
            .Select(g => new {
                Fecha = g.Key,
                Total = g.Sum(f => f.PrecioTotal)
            })
            .OrderBy(x => x.Fecha)
            .ToListAsync();

        // --- C. TOP 5 PRODUCTOS MÁS VENDIDOS ---
        // Esto requiere ir a la tabla DetallesFactura
        var topProductos = await _context.DetallesFactura
            .Include(d => d.Factura)
            .Include(d => d.Producto)
            .Where(d => d.Factura.FechaEmision >= inicioMes
                        && d.Factura.TipoFactura == "Venta"
                        && d.Factura.Estado != "Anulada")
            .GroupBy(d => d.Producto.Nombre)
            .Select(g => new ProductoTopVenta
            {
                NombreProducto = g.Key,
                CantidadVendida = g.Sum(d => d.Cantidad),
                // Asumiendo que podemos calcular el total aproximado
                TotalGenerado = g.Sum(d => d.Cantidad * d.PrecioUnitario)
            })
            .OrderByDescending(x => x.CantidadVendida)
            .Take(5)
            .ToListAsync();

        // --- C.2. TOP 5 CLIENTES ---
        var topClientes = await _context.Facturas
            .Where(f => f.FechaEmision >= inicioMes
                        && f.TipoFactura == "Venta"
                        && f.Estado != "Anulada")
            .GroupBy(f => f.Cliente != null ? f.Cliente.RazonSocial : "Consumidor final")
            .Select(g => new ClienteTopVenta
            {
                NombreCliente = g.Key,
                CantidadCompras = g.Count(),
                TotalGastado = g.Sum(f => f.PrecioTotal)
            })
            .OrderByDescending(x => x.TotalGastado)
            .Take(5)
            .ToListAsync();

        // --- D. ÚLTIMAS 5 VENTAS (Historial) ---
        var ultimasVentas = await _context.Facturas
            .Include(f => f.Cliente)
            .Include(f => f.Usuario)
            .Where(f => f.TipoFactura == "Venta" && f.Estado != "Anulada")
            .OrderByDescending(f => f.FechaEmision)
            .ThenByDescending(f => f.IDFactura)
            .Take(5)
            .ToListAsync();

        // 3. Armar el ViewModel
        var viewModel = new DashboardViewModel
        {
            VentasTotalesMes = totalVentas,
            CantidadFacturasMes = cantidadVentas,
            TicketPromedio = cantidadVentas > 0 ? totalVentas / cantidadVentas : 0,

            // Convertimos los datos del gráfico a Arrays para JavaScript
            GraficoEtiquetas = datosGrafico.Select(x => x.Fecha.ToString("dd/MM")).ToArray(),
            GraficoValores = datosGrafico.Select(x => x.Total).ToArray(),

            TopProductos = topProductos,
            TopClientes = topClientes,
            UltimasVentas = ultimasVentas
        };

        // --- E. LÓGICA DE ALMACÉN ---

        // 1. Calcular el Stock Actual de cada producto en memoria o BD
        // (Hacemos una proyección para traer solo lo necesario y no sobrecargar)
        var inventarioData = await _context.Productos
            .Include(p => p.Categoria)
            .Select(p => new
            {
                p.Nombre,
                p.Precio,
                p.CostoPromedio,
                p.StockMinimo,
                CategoriaNombre = p.Categoria.Nombre,
                // Lógica simplificada de stock: (Sumar Entradas - Sumar Salidas)
                // Ajusta los strings "Entrada"/"Salida" según como los guardes en tu BD
                p.StockActual
            })
            .ToListAsync();

        // 2. KPI: Valor del Inventario (Stock * Precio)
        viewModel.ValorTotalInventario = inventarioData.Sum(p => p.StockActual * p.CostoPromedio);
        viewModel.TotalReferencias = inventarioData.Count;

        // 3. GRÁFICO: Agrupar por Categoría (Cuántos productos hay en cada una + valor total)
        var datosCategoria = inventarioData
            .GroupBy(x => x.CategoriaNombre)
            .Select(g => new { 
                Categoria = g.Key, 
                Cantidad = g.Count(),
                ValorTotal = g.Sum(x => x.StockActual * x.CostoPromedio)
            })
            .OrderByDescending(x => x.Cantidad)
            .ToList();

        viewModel.CategoriasEtiquetas = datosCategoria.Select(x => x.Categoria).ToArray();
        viewModel.CategoriasValores = datosCategoria.Select(x => x.Cantidad).ToArray();
        viewModel.CategoriasDinero = datosCategoria.Select(x => x.ValorTotal).ToArray();

        // Filtrar la lista completa
        viewModel.InventarioCompleto = inventarioData
            .OrderBy(p => p.CategoriaNombre)
            .ThenBy(p => p.Nombre)
            .Select(p => new ProductoInventario
            {
                Nombre = p.Nombre,
                Categoria = p.CategoriaNombre,
                Stock = p.StockActual,
                Costo = p.CostoPromedio,
                ValorTotal = p.StockActual * p.CostoPromedio
            }).ToList();

        // 4. ALERTA: Productos con Stock por debajo del Mínimo
        viewModel.ProductosBajoStock = inventarioData
            .Where(p => p.StockActual <= p.StockMinimo + 5 && p.StockMinimo > 0) // Solo si definieron un mínimo
            .OrderBy(p => p.StockActual) // Los más críticos primero
            .Take(5)
            .Select(p => new ProductoAlertaStock
            {
                Nombre = p.Nombre,
                StockActual = p.StockActual,
                StockMinimo = p.StockMinimo,
                //CostoPromedio = p.CostoPromedio,
                Categoria = p.CategoriaNombre
            })
            .ToList();

        // --- F. LÓGICA DE FLUJO DE CAJA ---

        // 1. Calcular Egresos (Facturas de Compra del mes, no anuladas)
        var comprasMesQuery = _context.Facturas
            .Where(f => f.FechaEmision >= inicioMes
                        && f.TipoFactura == "Compra" // Asegúrate de que usas esta palabra exacta en BD
                        && f.Estado != "Anulada");

        decimal totalCompras = await comprasMesQuery.SumAsync(f => f.PrecioTotal);

        // 2. Asignar al ViewModel
        viewModel.TotalEgresos = totalCompras;

        // 3. Calcular Balance (Ventas - Compras)
        // Nota: 'totalVentas' ya lo calculaste en la sección comercial (Paso A)
        viewModel.BalanceNeto = totalVentas - totalCompras;

        // 4. Calcular Margen (Opcional, para evitar división por cero)
        if (totalVentas > 0)
        {
            viewModel.MargenGanancia = ((totalVentas - totalCompras) / totalVentas) * 100;
        }
        else
        {
            viewModel.MargenGanancia = 0;
        }

        // 5. Datos para el gráfico comparativo
        viewModel.FlujoValores = new decimal[] { totalVentas, totalCompras };

        return View(viewModel);
    }

    public async Task<IActionResult> AlertaStock()
    {
        var productosBajoStock = await _context.Productos
            .Include(p => p.Categoria)
            .Where(p => p.StockActual <= p.StockMinimo + 10 && p.StockMinimo > 0)
            .OrderBy(p => p.StockActual)
            .Select(p => new ProductoAlertaStock
            {
                Nombre = p.Nombre,
                StockActual = p.StockActual,
                StockMinimo = p.StockMinimo,
                Categoria = p.Categoria.Nombre
            })
            .ToListAsync();

        return View(productosBajoStock);
    }

    public IActionResult IndexGeneral()
    {
        var productos = _context.Productos.ToList();
        return View("IndexGeneral", productos);
    }


}